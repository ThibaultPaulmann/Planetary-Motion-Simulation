from SolarSystem import SolarSystem

# Script to run the SolarSystem Simulation
def main():
    
    solarSystem = SolarSystem()
    solarSystem.runSimulation()

if __name__ == "__main__":
    main()